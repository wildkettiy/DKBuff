-- 1. Create the Anchor (Title Bar) - Now 50% bigger
local BHA = CreateFrame("Frame", "BoneHornAlertAnchor", UIParent)
BHA:SetSize(300, 38) -- Increased from 200x25
BHA:SetPoint("CENTER", 0, 0)
BHA:SetBackdrop({
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 14,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
BHA:SetBackdropColor(0, 0, 0, 0.7) -- Slightly darker for better contrast

-- 2. Draggable Logic
BHA:SetMovable(true)
BHA:EnableMouse(true)
BHA:RegisterForDrag("LeftButton")
BHA:SetScript("OnDragStart", function(self) self:StartMoving() end)
BHA:SetScript("OnDragStop", function(self) 
    self:StopMovingOrSizing() 
    local p, _, rp, x, y = self:GetPoint()
    BHA_Pos = { p = p, rp = rp, x = x, y = y }
end)

-- 3. Title Text (Displays "Missing" info)
local titleText = BHA:CreateFontString(nil, "OVERLAY")
titleText:SetFont("Fonts\\FRIZQT__.TTF", 16, "OUTLINE") -- Larger font for larger bar
titleText:SetPoint("CENTER", BHA, "CENTER", 0, 0)
titleText:SetTextColor(1, 1, 1, 1)

-- 4. Bar Creation (For active timers)
local function CreateTimerBar(name, label)
    local bar = CreateFrame("StatusBar", nil, BHA)
    bar:SetSize(300, 22) -- Match width of title bar
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bar:SetStatusBarColor(0, 0, 0, 0.9)
    bar:SetFrameLevel(BHA:GetFrameLevel() + 1)
    
    local bg = bar:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture(0.1, 0.1, 0.1, 1)
    
    local text = bar:CreateFontString(nil, "OVERLAY")
    text:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE")
    text:SetPoint("CENTER", bar, "CENTER", 0, 0)
    text:SetTextColor(1, 1, 1, 1)
    
    bar.spell = name
    bar.label = label
    bar.text = text
    return bar
end

local bars = {
    CreateTimerBar("Knochenschild", "Schild"),
    CreateTimerBar("Horn des Winters", "Horn")
}

-- 5. Update Loop
local function UpdateUI()
    local missing = {}
    local yOffset = -5
    
    -- Check Pet
    if not UnitExists("pet") or UnitIsDead("pet") then
        table.insert(missing, "PET")
    end

    -- Update Buff Bars
    for _, bar in ipairs(bars) do
        local name, _, _, _, _, duration, expires = UnitBuff("player", bar.spell)
        if name and expires and expires > 0 then
            local remaining = expires - GetTime()
            bar:SetMinMaxValues(0, duration)
            bar:SetValue(remaining)
            bar.text:SetText(bar.label .. ": " .. math.floor(remaining) .. "s")
            bar.text:SetTextColor(remaining < 10 and 1 or 1, remaining < 10 and 0 or 1, remaining < 10 and 0 or 1)
            
            bar:ClearAllPoints()
            bar:SetPoint("TOP", BHA, "BOTTOM", 0, yOffset)
            bar:Show()
            yOffset = yOffset - 24
        else
            bar:Hide()
            table.insert(missing, bar.label) -- Add to missing list if not active
        end
    end

    -- Update Title Bar Text
    if #missing > 0 then
        titleText:SetText("FEHLT: " .. table.concat(missing, " + "))
        titleText:SetTextColor(1, 0, 0) -- Red when something is missing
    else
        titleText:SetText("ALLES AKTIV")
        titleText:SetTextColor(0, 1, 0) -- Green when all good
    end
end

BHA:SetScript("OnUpdate", UpdateUI)

BHA:RegisterEvent("ADDON_LOADED")
BHA:SetScript("OnEvent", function(self, event, arg1)
    if arg1 == "BoneHornAlert" and BHA_Pos then
        self:ClearAllPoints()
        self:SetPoint(BHA_Pos.p, UIParent, BHA_Pos.rp, BHA_Pos.x, BHA_Pos.y)
    end
end)